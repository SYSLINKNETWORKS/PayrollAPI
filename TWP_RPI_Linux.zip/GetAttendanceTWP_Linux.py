import sys

sys.path.append("zk")

import requests

import logging

import os

from zk import ZK, const

from datetime import datetime, timedelta




_urlstr='https://demo.syslinknetwork.com:260/api/Payroll/v1/PayrollDashboard'



def getMachineDetail():

    response = requests.get(_urlstr+'/GetAttendanceMachineIp',headers={'GroupId':'D5BBE70E-0039-4704-9F93-46CC008FFF2C'})

    if response.json()["statusCode"] != '200':
        
        # This means something went wrong.

        print ('GET /tasks/ {}'.format(str(response.json()["statusCode"])+ ' ' +response.json()["message"]))





    
    if response.json()["statusCode"] == '200':
        #print (resp.json()["statusCode"])

        for todo_item1 in response.json()["data"]:

            _mac_id=todo_item1["id"]

            _IP_Address=todo_item1["ip"]

            _Port=todo_item1["port"]


            print ('Machine IP '+ _IP_Address )

            getatt(_IP_Address,_Port,_mac_id)




def getatt(_IP,_Port,_mac_id):    

    _DetailStr=''


    conn = None

    zk = ZK(_IP, port=_Port, timeout=5, password=0, force_udp=False, ommit_ping=False)
    try:

    

        print ('Connecting to device ...')

        conn = zk.connect()    

        atts = conn.get_attendance()        

        

        print('Machine IP : '+str(_IP)+' Record : ' + str(atts[0]))
        _DetailStr= []
        sno=1
        for attlog in atts:
                #if sno<10:
                _DetailStr1={"userId":""+ attlog.user_id+"","checkTime":""+str(attlog.timestamp)+"","machineId":""+str(_mac_id)+""}
                _DetailStr.append(_DetailStr1)
                sno+=1
       
        print ('Machine # '+str(_mac_id) +' Record # '+str(sno));
        if (_DetailStr!=''):
            insrec(_DetailStr)

    except Exception as e:
        print ("Process terminate : {}".format(e))



    finally:


        if conn:

            conn.disconnect()



def insrec(_Detail):  
    #print (_Detail)
    detailResult= {"checkInOutMachineModels":_Detail}
    #print (detailResult)  

    response = requests.post(_urlstr+'/AttendanceMachinePost/',json=detailResult)
    print(response.json())
    if response.json()["statusCode"] != 200:

        # This means something went wrong.

        print ('Post /tasks/ {}'.format(str(response.status_code)+ ' ' +response.reason))


    #for todo_item in resp.json():

    print('{}'.format(response.json()["message"]))



while True:
    getMachineDetail()

    



